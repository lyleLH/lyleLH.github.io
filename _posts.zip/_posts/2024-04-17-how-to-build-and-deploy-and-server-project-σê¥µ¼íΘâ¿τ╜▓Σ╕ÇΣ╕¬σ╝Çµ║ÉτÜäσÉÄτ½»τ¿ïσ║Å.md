---
layout: post
title: How to build and deploy and server project? 初次部署一个开源的后端程序.
date: 2024-04-17 20:04 +0800
---

![飞机](https://cdn.pixabay.com/photo/2023/10/14/23/27/airplane-8315886_1280.jpg)

## 购买服务器

首先你得先购买一台云服务器,为其选择安装 CentOS 系统

## 配置运行环境

网站应用在服务器运行需要很多服务

- 数据库, MySQL
- 软件运行时, NodeJS
- 源代码管理, Git

### 安装 MySQL

### 安装 Git

### 安装 NodeJS

## 数据库准备

### 初始化数据库

#### seed 脚本

### 远端连接

验证数据已经写入

## 拉取源代码编译并运行

### 配置数据库连接

### 编译运行

### 接口测试
