---
layout: article
author: Tom Liu
title: How to set componentize projects goal
date: 2022-11-03 10:42 +0800
tag: ["Project Manage", "Devops"]
---

## 架构设计

## 评价标准

## 评分算法

## 前端实现

![业务结构](/assets/2022-11-03-how-to-set-componentize-projects-goal/project_list.jpeg)

![业务结构](/assets/2022-11-03-how-to-set-componentize-projects-goal/project_details.png)
